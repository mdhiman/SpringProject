package com.example.admission;

import java.util.List;

public class DiseaseList {
	
	List<Disease> pathologyList ;

	public DiseaseList() {
		// TODO Auto-generated constructor stub
	}

	public List<Disease> getPathologyList() {
		return pathologyList;
	}

	public void setPathologyList(List<Disease> pathologyList) {
		this.pathologyList = pathologyList;
	}
	
	

}
